package com.data;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBUtil {

	public static Connection createConnection() {
		Connection con = null;
		String JDBC_URL = "jdbc:sqlserver://localhost:1433;databaseName=NINA;integratedSecurity=true;encrypt=true;trustServerCertificate=true;";

		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(JDBC_URL);
			System.out.println("Printing connection object "+con);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return con;
	}

}
