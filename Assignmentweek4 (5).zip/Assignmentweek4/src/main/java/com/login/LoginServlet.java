package com.login;

import java.io.IOException;
import com.data.UserDAO;
import com.data.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        userDAO = new UserDAO(); // Initialize UserDAO in servlet's init() method
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve username and password from login form
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check if username and password are provided
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {

            if (username == null || username.isEmpty()) {
                request.setAttribute("usernameError", "Username is required");
            }
            if (password == null || password.isEmpty()) {
                request.setAttribute("passwordError", "Password is required");
            }
            // Forward back to login page with error messages
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        // Authenticate user
        User user = userDAO.loginUser(username, password);

        // Check if user is authenticated
        if (user != null) {
            // If authentication successful, forward to welcome page
            request.setAttribute("user", user);
            request.getRequestDispatcher("welcome.jsp").forward(request, response);
        } else {
            // If authentication fails, set error message and forward back to login page
            request.setAttribute("error", "Invalid username or password");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
