package com.register;

import com.data.User;
import com.data.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        userDAO = new UserDAO(); // Initialize UserDAO in servlet's init() method
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve registration form parameters
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check for empty fields
        if (isEmpty(firstName)) {
            request.setAttribute("firstNameError", "First Name is required");
        }
        if (isEmpty(lastName)) {
            request.setAttribute("lastNameError", "Last Name is required");
        }
        if (isEmpty(username)) {
            request.setAttribute("usernameError", "Username is required");
        } else {
            // Check if the user already exists only if the username is in a valid email format
            if (!isValidUsername(username)) {
                request.setAttribute("usernameError", "Invalid email format");
            } else if (userDAO.isUserExists(username)) {
                // If the user already exists, set an attribute indicating that the username is already taken
                request.setAttribute("usernameError", "The username is already taken. Choose a new username.");
            }
        }
        if (isEmpty(password)) {
            request.setAttribute("passwordError", "Password is required");
        }

        // If any errors, forward back to registration page
        if (request.getAttribute("firstNameError") != null || request.getAttribute("lastNameError") != null || request.getAttribute("usernameError") != null ||
                request.getAttribute("passwordError") != null) {
            request.getRequestDispatcher("/register.jsp").forward(request, response);
            return;
        }

        // Create a new User object with the provided information
        User user = new User(0, firstName, lastName, username, password);

        // Register the user
        boolean registrationSuccess = userDAO.registerUser(user);

        if (registrationSuccess) {
            // If registration is successful, redirect to a success page
            response.sendRedirect("registrationSuccess.jsp");
        } else {
            // If registration fails, redirect back to registration page 
            response.sendRedirect("register.jsp?registrationError=true");
        }
    }

    private boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    private boolean isValidUsername(String username) {
        // Regular expression for basic email validation
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();
    }
}
