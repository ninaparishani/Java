
//Create an interface
public interface Payroll {
	void generatePayroll();

}
