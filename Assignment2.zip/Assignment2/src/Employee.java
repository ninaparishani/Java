

//Create an Abstract Class Employee
public abstract class Employee {
	public double grossPay;
	public double taxes;
	public double netPay;
	
	public abstract void generatePayroll();
	}

